public class pattern {

    public static void main(String[] args) {
        // for (int i = 1; i <= 5; i++) {
        //     for (int j = 1; j <= i; j++) {
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

             
        // for (int i = 1; i <= 5; i++) {
        //     for (int j = 1; j <= i; j++) {
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

    
        
            // int rows = 5; 
            // int columns = 10; 
            
            // for (int i = 0; i < rows; i++) {
            //     for (int j = 0; j < columns; j++) {
            //         System.out.print("*");
            //     }
            //     System.out.println(); 
            // }

            // for (int i = 1; i <=5 ; i++) {
            //   for (int j = 1; j <= i; j++) {
            //     System.out.print(i);
            //   }
            //   System.out.println();
            // }

            // for (int i = 5; i >= 1 ; i--) {
            //     for (int j = 1; j <=i; j++) {
            //         System.out.print(i);
            //     }
            //     System.out.println();
            // }

            // for (int i = 1; i <= 4; i++) {
            //     for (int j = 1; j <= i*2-1; j++) {
            //         System.out.print(j);
            //     }
            //     System.out.println();
            // }    

            // for (int i = 1; i <= 4; i++) {
            //     for (int j = 1; j <= i*2; j++) {
            //         System.out.print(j);
            //     }
            //     System.out.println();
                
            // }
        }
    
    

    }
