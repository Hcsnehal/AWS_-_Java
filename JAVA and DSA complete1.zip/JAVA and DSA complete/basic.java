import java.util.*;
public class basic {
    //2) Write a Program to Print Integer Number Entered by User
    public static void main(String[] args) {
    //     Scanner sc = new Scanner(System.in);
    //     System.out.println("entwer a num :");
    //     int a = sc.nextInt();
    //     System.out.println(a);
        
    
    

    //3 Write a Program to Add Two Integer Numbers Entered by user .
    Scanner sc = new Scanner(System.in);
    // System.out.println("enter the first num :");
    // int a = sc.nextInt();

    // System.out.println("enter the second num :");
    // int b = sc.nextInt();

    // int c = a+b;
    // System.out.println("addition of two num is " +c);


    //Write a Program to Multiply two decimal Numbers
    //entered by User
    // System.out.println("enter a first num :");
    // float a = sc.nextFloat();

    // System.out.println("enter the second num :");
    // float b = sc.nextFloat();

    // float c = a+b;
    // System.out.println(c);

    // Write a Program to Find ASCII Value of a Character

//     System.out.println("enter a character :");
//     char ch = sc.next().charAt(0);
    
//    int ascivaliu = (int) ch;
//    System.out.println(ascivaliu);


// programm for swap of two number //

//  int a = 10;
//  int b = 12;
//  System.out.println("before swapping value of a :" +a);
//  System.out.println("before swapping value of b :" +b);

//  int rev = a;
//  a = b;
//  b = rev;
// System.out.println("after swapping value of a " +a);
// System.out.println("after swapping value of b " +b);


// find ascii value of character//

// char ch = 'a';
// int c = ch;
// System.out.println("ascii value of a is " +c); 

//Write a Program to Find Size of int, float, double and char
//in your computer..

// System.out.println("size of int is " +(Integer.SIZE/8));

// System.out.println("size of char is " +(Character.SIZE/8));

// System.out.println("size of flot is " +(Float.SIZE/8));

// System.out.println("size of double is " +(Double.SIZE/8));

// Integer.SIZE returns the number of bits used to represent an int value, which is 32 bits.
// Dividing by 8 gives the size in bytes.

// //
// System.out.println("enter a num =");
// int a = sc.nextInt();

// System.out.println("enter a second num =");
// int b = sc.nextInt();

// System.out.println("quotiant of a and b is " +(a/b));
// System.out.println("reminder od a and b is "+(a%b));

    }
}
