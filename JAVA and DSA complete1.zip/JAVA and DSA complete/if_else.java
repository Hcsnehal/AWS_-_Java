import java.util.*;
public class if_else {
    public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
    
//     System.out.println("enter a num =");
//     int a = sc.nextInt();
//     if(a % 2 == 0){
//         System.out.println("num is even ");
//     }else{
//         System.out.println("num is odd");
//     }
   




//2) Write a Program to Check Whether a Character is
//Vowel or Consonant.
// do{
// System.out.println("enter a character =");
// int ch = sc.next().charAt(0);

// if(ch=='A' || ch =='E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o'|| ch =='u' ){
//     System.out.println("character is vowel ");

// }else{
//     System.out.println("not vowel ");
// } }while(true);

//3) Write a Program to Find Largest Number Among Three
//Numbers entered by users
// System.out.println("enter a first num =");
// int a = sc.nextInt();

// System.out.println("enter a second num =");
// int b = sc.nextInt();

// System.out.println("enter a third num =");
// int c = sc.nextInt();


//     if(a > b){
//         System.out.println("a is greater ");
//     }else if (b > c) {
//         System.out.println("b is greater ");
        
//     } else if(c > a){
//         System.out.println("c is greater ");
    //}


// Write a Program to Check whether a year entered by
// user is Leap Year or not
// do{
// System.out.println("enter a year");
// int year = sc.nextInt();

// if((year % 4 == 0) && (year % 100!=0) || (year % 400 == 0)){
//     System.out.println("year is leap year ");
// }else{
//     System.out.println("not a leap year");
// }}while(true);
        



}}